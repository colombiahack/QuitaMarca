const assert = require('assert');
const { fillRect } = require('../js/inpaint.js');

const W = 120, H = 80;
function gradient() {
  const d = new Uint8ClampedArray(W * H * 4);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const i = (y * W + x) * 4;
    d[i] = x * 2; d[i + 1] = y * 3; d[i + 2] = 100; d[i + 3] = 255;
  }
  return d;
}
function stamp(d, r) {
  for (let y = r.y; y < r.y + r.h; y++) for (let x = r.x; x < r.x + r.w; x++) {
    const i = (y * W + x) * 4; d[i] = 255; d[i + 1] = 255; d[i + 2] = 255;
  }
}
function meanErr(a, b, r) {
  let s = 0, n = 0;
  for (let y = r.y; y < r.y + r.h; y++) for (let x = r.x; x < r.x + r.w; x++)
    for (let c = 0; c < 3; c++) { s += Math.abs(a[(y * W + x) * 4 + c] - b[(y * W + x) * 4 + c]); n++; }
  return s / n;
}

// 1) Región interior: el degradado se recupera casi exacto y fuera no cambia
let ref = gradient(), img = gradient();
let r = { x: 80, y: 50, w: 30, h: 15 };
stamp(img, r);
const before = Uint8ClampedArray.from(img);
fillRect(img, W, H, r, { margin: 0 });
assert(meanErr(img, ref, r) < 2, 'error interior ' + meanErr(img, ref, r));
for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
  if (x >= r.x && x < r.x + r.w && y >= r.y && y < r.y + r.h) continue;
  for (let c = 0; c < 4; c++) assert.strictEqual(img[(y * W + x) * 4 + c], before[(y * W + x) * 4 + c]);
}

// 2) Región pegada a la esquina (sin bordes en dos lados)
img = gradient(); r = { x: W - 30, y: H - 15, w: 30, h: 15 };
stamp(img, r); fillRect(img, W, H, r, { margin: 2 });
assert(meanErr(img, ref, r) < 12, 'error esquina ' + meanErr(img, ref, r));

// 3) Casos límite: sin errores
fillRect(img, W, H, { x: 0, y: 0, w: W, h: H });
fillRect(img, W, H, { x: -10, y: -10, w: 5, h: 5 });
console.log('OK');
