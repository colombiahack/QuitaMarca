const assert = require('assert');
const { blurRect, pixelateRect, adjust, isNeutral } = require('../js/effects.js');

const W = 40, H = 30;
const mk = (f) => { const d = new Uint8ClampedArray(W * H * 4); for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) { const i = (y * W + x) * 4; const [r, g, b] = f(x, y); d[i] = r; d[i + 1] = g; d[i + 2] = b; d[i + 3] = 255; } return d; };
const at = (d, x, y) => { const i = (y * W + x) * 4; return [d[i], d[i + 1], d[i + 2]]; };

// blur: color plano no cambia; ruido se suaviza; fuera de la zona no cambia
let d = mk(() => [100, 150, 200]);
blurRect(d, W, H, { x: 5, y: 5, w: 20, h: 15 }, 4);
assert.deepStrictEqual(at(d, 10, 10), [100, 150, 200]);
d = mk((x, y) => ((x + y) % 2 ? [255, 255, 255] : [0, 0, 0]));
const out = at(d, 0, 0);
blurRect(d, W, H, { x: 5, y: 5, w: 20, h: 15 }, 3);
const m = at(d, 15, 12);
assert(m[0] > 100 && m[0] < 155, 'ajedrez debe tender a gris: ' + m[0]);
assert.deepStrictEqual(at(d, 0, 0), out);

// pixelado: bloques uniformes
d = mk((x, y) => [x * 6, y * 8, 50]);
pixelateRect(d, W, H, { x: 0, y: 0, w: 16, h: 16 }, 8);
assert.deepStrictEqual(at(d, 1, 1), at(d, 6, 6));
assert.notDeepStrictEqual(at(d, 1, 1), at(d, 9, 1));

// ajustes
assert(isNeutral({ brightness: 0, contrast: 0, saturation: 0, gray: false }));
d = mk(() => [100, 100, 100]); adjust(d, { brightness: 20 });
assert(at(d, 0, 0)[0] > 140 && at(d, 0, 0)[0] < 160);
d = mk(() => [200, 80, 40]); adjust(d, { gray: true });
const g = at(d, 3, 3); assert(g[0] === g[1] && g[1] === g[2] || Math.abs(g[0] - g[2]) <= 1);
d = mk(() => [128, 128, 128]); adjust(d, { contrast: 50 });
assert(Math.abs(at(d, 0, 0)[0] - 128) < 3); // gris medio casi no cambia
d = mk((x) => [x < 20 ? 90 : 170, 128, 128]); adjust(d, { contrast: 60 });
assert(at(d, 0, 0)[0] < 90 && at(d, 30, 0)[0] > 170);
console.log('effects OK');
