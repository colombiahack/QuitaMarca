(function () {
  'use strict';
  var $ = function (id) { return document.getElementById(id); };
  var view = $('view'), overlay = $('overlay'), octx = overlay.getContext('2d');
  var fileInput = $('file'), statusEl = $('status');
  var media = null;          // {kind, el, w, h, url, name}
  var tool = 'crop';
  var S = newState();
  var pendingCrop = null, drag = null;
  var busy = false, cancelled = false, rafPending = false, playing = false, scrubbing = false;
  var dlUrl = null;

  function newState() {
    return {
      rot: 0, flip: false, crop: { x: 0, y: 0, w: 1, h: 1 }, zones: [],
      adjust: { brightness: 0, contrast: 0, saturation: 0, gray: false },
      text: { value: '', color: '#ffffff', size: 7, bold: true, outline: true, x: 0.5, y: 0.85 },
      logo: { img: null, size: 20, opacity: 100, x: 0.85, y: 0.12 },
      trim: { start: 0, end: 0 }
    };
  }
  function setStatus(t) { statusEl.textContent = t; }

  // ---------- geometría de fracciones ----------
  var T = {
    cw:  { rect: function (r) { return { x: 1 - r.y - r.h, y: r.x, w: r.h, h: r.w }; }, pt: function (p) { return { x: 1 - p.y, y: p.x }; } },
    ccw: { rect: function (r) { return { x: r.y, y: 1 - r.x - r.w, w: r.h, h: r.w }; }, pt: function (p) { return { x: p.y, y: 1 - p.x }; } },
    flip: { rect: function (r) { return { x: 1 - r.x - r.w, y: r.y, w: r.w, h: r.h }; }, pt: function (p) { return { x: 1 - p.x, y: p.y }; } }
  };
  function transformAll(t) {
    S.crop = t.rect(S.crop);
    S.zones = S.zones.map(function (z) { var r = t.rect(z); return Object.assign({}, z, r); });
    var tp = t.pt({ x: S.text.x, y: S.text.y }); S.text.x = tp.x; S.text.y = tp.y;
    var lp = t.pt({ x: S.logo.x, y: S.logo.y }); S.logo.x = lp.x; S.logo.y = lp.y;
    pendingCrop = null;
  }
  function rotate(cw) {
    S.rot = (S.rot + (cw ? 1 : 3) * (S.flip ? 3 : 1)) % 4; // con volteo, el giro visual va al revés
    transformAll(cw ? T.cw : T.ccw);
  }
  function flipH() { S.flip = !S.flip; transformAll(T.flip); }

  // Cambia el recorte y reubica zonas/texto/logo para que sigan sobre lo mismo
  function setCrop(n) {
    var o = S.crop, zs = [];
    S.zones.forEach(function (z) {
      var x0 = o.x + z.x * o.w, y0 = o.y + z.y * o.h, x1 = x0 + z.w * o.w, y1 = y0 + z.h * o.h;
      x0 = Math.max(x0, n.x); y0 = Math.max(y0, n.y); x1 = Math.min(x1, n.x + n.w); y1 = Math.min(y1, n.y + n.h);
      if (x1 - x0 < 0.003 || y1 - y0 < 0.003) return;
      zs.push(Object.assign({}, z, { x: (x0 - n.x) / n.w, y: (y0 - n.y) / n.h, w: (x1 - x0) / n.w, h: (y1 - y0) / n.h }));
    });
    function pt(p) { return { x: clamp01((o.x + p.x * o.w - n.x) / n.w), y: clamp01((o.y + p.y * o.h - n.y) / n.h) }; }
    var t = pt({ x: S.text.x, y: S.text.y }); S.text.x = t.x; S.text.y = t.y;
    var l = pt({ x: S.logo.x, y: S.logo.y }); S.logo.x = l.x; S.logo.y = l.y;
    S.zones = zs; S.crop = n; pendingCrop = null;
  }
  function clamp01(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }

  // ---------- carga ----------
  fileInput.addEventListener('change', function () { var f = fileInput.files[0]; if (f) load(f); fileInput.value = ''; });

  function load(file) {
    if (busy) return;
    if (media && media.url) URL.revokeObjectURL(media.url);
    stopPlayback();
    var url = URL.createObjectURL(file);
    if (file.type.indexOf('image/') === 0) {
      var img = new Image();
      img.onload = function () { open({ kind: 'image', el: img, w: img.naturalWidth, h: img.naturalHeight, url: url, name: file.name }); };
      img.onerror = function () { setStatus('No se pudo leer la imagen.'); };
      img.src = url;
    } else if (file.type.indexOf('video/') === 0) {
      var v = document.createElement('video');
      v.playsInline = true; v.preload = 'auto'; v.loop = false;
      v.onloadeddata = function () {
        v.onloadeddata = null;
        open({ kind: 'video', el: v, w: v.videoWidth, h: v.videoHeight, url: url, name: file.name });
      };
      v.onerror = function () { setStatus('No se pudo leer el video (formato no soportado por este navegador).'); };
      v.addEventListener('seeked', requestDraw);
      v.addEventListener('play', onPlay); v.addEventListener('pause', onPause); v.addEventListener('ended', onPause);
      v.src = url;
    } else setStatus('Formato no soportado.');
  }

  function open(m) {
    media = m; S = newState(); pendingCrop = null; drag = null;
    if (m.kind === 'video') S.trim = { start: 0, end: m.el.duration || 0 };
    $('editor').hidden = false;
    $('transport').hidden = m.kind !== 'video';
    $('trimBox').hidden = m.kind !== 'video';
    $('imgOpts').hidden = m.kind !== 'image';
    $('vidOpts').hidden = m.kind !== 'video';
    resetOutputs(); syncUI(); setTool('crop');
    setStatus(m.name + ' (' + m.w + '×' + m.h + ')');
    updateTrimInfo();
    requestDraw();
  }

  // ---------- herramientas ----------
  function setTool(t) {
    tool = t; drag = null;
    document.querySelectorAll('#tools button').forEach(function (b) { b.classList.toggle('on', b.dataset.tool === t); });
    document.querySelectorAll('.panel').forEach(function (p) { p.hidden = p.dataset.panel !== t; });
    overlay.style.cursor = (t === 'adjust' || t === 'export') ? 'default' : 'crosshair';
    requestDraw();
  }
  $('tools').addEventListener('click', function (e) { var b = e.target.closest('button'); if (b && !busy) setTool(b.dataset.tool); });

  // ---------- dibujo ----------
  function requestDraw() {
    if (rafPending) return; rafPending = true;
    requestAnimationFrame(function () { rafPending = false; draw(); });
  }

  function draw(fast) {
    if (!media) return;
    var rs = Studio.rotatedSize(media.w, media.h, S.rot), c = tool === 'crop' ? { w: 1, h: 1 } : S.crop;
    var scale = Math.min(1, 960 / Math.max(rs.w * c.w, rs.h * c.h));
    Studio.render(media.el, media.w, media.h, S, { scale: scale, ignoreCrop: tool === 'crop', fast: !!fast || playing }, view);
    if (overlay.width !== view.width || overlay.height !== view.height) { overlay.width = view.width; overlay.height = view.height; }
    drawOverlay();
    if (media.kind === 'video') updateTime();
  }

  function R(r) { return [r.x * overlay.width, r.y * overlay.height, r.w * overlay.width, r.h * overlay.height]; }

  function drawOverlay() {
    var w = overlay.width, h = overlay.height, lw = Math.max(2, w / 300);
    octx.clearRect(0, 0, w, h);
    octx.lineWidth = lw;
    if (tool === 'crop') {
      var cr = (drag && !drag.move) ? dragRect(drag) : (pendingCrop || S.crop);
      if (!drag && !pendingCrop && S.crop.w === 1 && S.crop.h === 1) return;
      octx.fillStyle = 'rgba(0,0,0,.55)'; octx.fillRect(0, 0, w, h);
      var a = R(cr); octx.clearRect(a[0], a[1], a[2], a[3]);
      octx.strokeStyle = '#fff'; octx.setLineDash([lw * 3, lw * 2]); octx.strokeRect(a[0], a[1], a[2], a[3]); octx.setLineDash([]);
    } else if (tool === 'blur' || tool === 'remove') {
      octx.strokeStyle = '#ff3b30'; octx.fillStyle = 'rgba(255,59,48,.15)';
      var list = S.zones.filter(function (z) { return (tool === 'remove') === (z.kind === 'fill'); });
      if (drag && !drag.move) list.push(dragRect(drag));
      list.forEach(function (z) { var a2 = R(z); octx.fillRect(a2[0], a2[1], a2[2], a2[3]); octx.strokeRect(a2[0], a2[1], a2[2], a2[3]); });
    } else if (tool === 'text' || tool === 'logo') {
      var p = tool === 'text' ? S.text : S.logo;
      octx.strokeStyle = '#ff3b30'; octx.beginPath();
      octx.arc(p.x * w, p.y * h, Math.max(8, w / 60), 0, Math.PI * 2); octx.stroke();
    }
  }

  // ---------- puntero ----------
  function frac(e) {
    var r = overlay.getBoundingClientRect();
    return { x: clamp01((e.clientX - r.left) / r.width), y: clamp01((e.clientY - r.top) / r.height) };
  }
  function dragRect(d) {
    return { x: Math.min(d.x0, d.x1), y: Math.min(d.y0, d.y1), w: Math.abs(d.x1 - d.x0), h: Math.abs(d.y1 - d.y0) };
  }
  overlay.addEventListener('pointerdown', function (e) {
    if (!media || busy || tool === 'adjust' || tool === 'export') return;
    overlay.setPointerCapture(e.pointerId);
    var p = frac(e);
    if (tool === 'text') { S.text.x = p.x; S.text.y = p.y; drag = { move: true }; requestDraw(); return; }
    if (tool === 'logo') { S.logo.x = p.x; S.logo.y = p.y; drag = { move: true }; requestDraw(); return; }
    drag = { x0: p.x, y0: p.y, x1: p.x, y1: p.y };
  });
  overlay.addEventListener('pointermove', function (e) {
    if (!drag) return;
    var p = frac(e);
    if (drag.move) { var o = tool === 'text' ? S.text : S.logo; o.x = p.x; o.y = p.y; }
    else { drag.x1 = p.x; drag.y1 = p.y; }
    requestDraw();
  });
  overlay.addEventListener('pointerup', function () {
    if (!drag) return;
    var d = drag; drag = null;
    if (!d.move) {
      var r = dragRect(d);
      if (r.w > 0.01 && r.h > 0.01) {
        if (tool === 'crop') pendingCrop = r;
        else if (tool === 'blur') S.zones.push(Object.assign(r, { kind: $('bKind').value, strength: +$('bStr').value }));
        else if (tool === 'remove') S.zones.push(Object.assign(r, { kind: 'fill', margin: +$('rMargin').value }));
      }
    }
    requestDraw();
  });
  overlay.addEventListener('pointercancel', function () { drag = null; requestDraw(); });

  // ---------- recorte y giro ----------
  $('rotL').addEventListener('click', function () { if (media && !busy) { rotate(false); requestDraw(); } });
  $('rotR').addEventListener('click', function () { if (media && !busy) { rotate(true); requestDraw(); } });
  $('flipH').addEventListener('click', function () { if (media && !busy) { flipH(); requestDraw(); } });
  $('ratios').addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b || !media || busy) return;
    var ar = +b.dataset.ar, rs = Studio.rotatedSize(media.w, media.h, S.rot);
    if (!ar) { pendingCrop = { x: 0.05, y: 0.05, w: 0.9, h: 0.9 }; requestDraw(); return; }
    var w = 1, h = (rs.w / ar) / rs.h;
    if (h > 1) { h = 1; w = (rs.h * ar) / rs.w; }
    pendingCrop = { x: (1 - w) / 2, y: (1 - h) / 2, w: w, h: h };
    requestDraw();
  });
  $('cropApply').addEventListener('click', function () {
    if (!media || busy) return;
    if (!pendingCrop) { setStatus('Arrastra sobre la imagen para elegir el recorte.'); return; }
    setCrop(pendingCrop); setStatus('Recorte aplicado.'); setTool('adjust');
  });
  $('cropReset').addEventListener('click', function () {
    if (!media || busy) return;
    setCrop({ x: 0, y: 0, w: 1, h: 1 }); requestDraw();
  });

  // ---------- recorte de video (inicio/fin) ----------
  function fmt(t) { t = Math.max(0, t || 0); var m = Math.floor(t / 60), s = (t % 60).toFixed(1); return m + ':' + (s < 10 ? '0' : '') + s; }
  function updateTrimInfo() { if (media && media.kind === 'video') $('trimInfo').textContent = fmt(S.trim.start) + ' → ' + fmt(S.trim.end); }
  $('setStart').addEventListener('click', function () {
    var t = media.el.currentTime; if (t >= S.trim.end - 0.2) { setStatus('El inicio debe ir antes del fin.'); return; }
    S.trim.start = t; updateTrimInfo();
  });
  $('setEnd').addEventListener('click', function () {
    var t = media.el.currentTime; if (t <= S.trim.start + 0.2) { setStatus('El fin debe ir después del inicio.'); return; }
    S.trim.end = t; updateTrimInfo();
  });

  // ---------- reproducción (vista previa) ----------
  function schedule(fn) { var v = media.el; if (v.requestVideoFrameCallback) v.requestVideoFrameCallback(fn); else requestAnimationFrame(fn); }
  function previewLoop() { if (!playing || busy) return; draw(true); schedule(previewLoop); }
  function onPlay() { playing = true; $('play').textContent = '⏸'; schedule(previewLoop); }
  function onPause() { playing = false; $('play').textContent = '▶'; requestDraw(); }
  function stopPlayback() { if (media && media.kind === 'video') { media.el.pause(); } playing = false; }
  $('play').addEventListener('click', function () {
    if (!media || busy) return;
    var v = media.el;
    if (v.paused) {
      if (v.currentTime < S.trim.start || v.currentTime >= S.trim.end - 0.05) v.currentTime = S.trim.start;
      v.play().catch(function () { setStatus('El navegador bloqueó la reproducción.'); });
    } else v.pause();
  });
  $('scrub').addEventListener('input', function () {
    if (!media || busy) return; scrubbing = true;
    media.el.currentTime = ($('scrub').value / 1000) * (media.el.duration || 0);
  });
  $('scrub').addEventListener('change', function () { scrubbing = false; });
  function updateTime() {
    var v = media.el;
    $('time').textContent = fmt(v.currentTime) + ' / ' + fmt(v.duration);
    if (!scrubbing && v.duration) $('scrub').value = (v.currentTime / v.duration) * 1000;
  }

  // ---------- controles ----------
  function bind(id, fn, ev) { $(id).addEventListener(ev || 'input', function () { fn(); requestDraw(); }); }
  bind('adjBr', function () { S.adjust.brightness = +$('adjBr').value; });
  bind('adjCt', function () { S.adjust.contrast = +$('adjCt').value; });
  bind('adjSa', function () { S.adjust.saturation = +$('adjSa').value; });
  bind('adjGray', function () { S.adjust.gray = $('adjGray').checked; }, 'change');
  $('adjReset').addEventListener('click', function () { S.adjust = { brightness: 0, contrast: 0, saturation: 0, gray: false }; syncUI(); requestDraw(); });
  bind('tText', function () { S.text.value = $('tText').value; });
  bind('tColor', function () { S.text.color = $('tColor').value; });
  bind('tBold', function () { S.text.bold = $('tBold').checked; }, 'change');
  bind('tOutline', function () { S.text.outline = $('tOutline').checked; }, 'change');
  bind('tSize', function () { S.text.size = +$('tSize').value; });
  bind('lSize', function () { S.logo.size = +$('lSize').value; });
  bind('lOpacity', function () { S.logo.opacity = +$('lOpacity').value; });
  $('logoFile').addEventListener('change', function () {
    var f = $('logoFile').files[0]; if (!f) return;
    var img = new Image(), u = URL.createObjectURL(f);
    img.onload = function () { S.logo.img = img; requestDraw(); setStatus('Logo cargado. Arrastra sobre la imagen para moverlo.'); };
    img.onerror = function () { setStatus('No se pudo leer el logo.'); };
    img.src = u; $('logoFile').value = '';
  });
  $('logoRemove').addEventListener('click', function () { S.logo.img = null; requestDraw(); });

  function undoZone(fill) {
    for (var i = S.zones.length - 1; i >= 0; i--) if ((S.zones[i].kind === 'fill') === fill) { S.zones.splice(i, 1); break; }
    requestDraw();
  }
  function clearZones(fill) { S.zones = S.zones.filter(function (z) { return (z.kind === 'fill') !== fill; }); requestDraw(); }
  $('bUndo').addEventListener('click', function () { undoZone(false); });
  $('bClear').addEventListener('click', function () { clearZones(false); });
  $('rUndo').addEventListener('click', function () { undoZone(true); });
  $('rClear').addEventListener('click', function () { clearZones(true); });

  function syncUI() {
    $('adjBr').value = S.adjust.brightness; $('adjCt').value = S.adjust.contrast; $('adjSa').value = S.adjust.saturation;
    $('adjGray').checked = S.adjust.gray;
    $('tText').value = S.text.value; $('tColor').value = S.text.color; $('tBold').checked = S.text.bold;
    $('tOutline').checked = S.text.outline; $('tSize').value = S.text.size;
    $('lSize').value = S.logo.size; $('lOpacity').value = S.logo.opacity;
  }
  $('resetAll').addEventListener('click', function () {
    if (!media || busy) return;
    var trim = media.kind === 'video' ? { start: 0, end: media.el.duration } : S.trim;
    S = newState(); S.trim = trim; pendingCrop = null; syncUI(); updateTrimInfo(); resetOutputs(); requestDraw();
    setStatus('Edición restablecida.');
  });

  // ---------- exportar ----------
  function resetOutputs() {
    $('download').hidden = true; $('result').hidden = true; $('bar').hidden = true;
    if (dlUrl) { URL.revokeObjectURL(dlUrl); dlUrl = null; }
  }
  function base(n) { return n.replace(/\.[^.]+$/, ''); }
  function offerDownload(blob, name, label) {
    if (dlUrl) URL.revokeObjectURL(dlUrl);
    dlUrl = URL.createObjectURL(blob);
    var a = $('download'); a.href = dlUrl; a.download = name; a.textContent = label; a.hidden = false;
    return dlUrl;
  }
  function setBusy(b) {
    busy = b;
    $('runExport').disabled = b; $('cancelExport').hidden = !(b && media && media.kind === 'video');
  }

  $('runExport').addEventListener('click', function () {
    if (!media || busy) return;
    if (media.kind === 'image') exportImage(); else exportVideo();
  });

  function exportImage() {
    var jpeg = $('imgFmt').value === 'jpeg', c = document.createElement('canvas');
    resetOutputs();
    Studio.render(media.el, media.w, media.h, S, { scale: 1, background: jpeg ? '#ffffff' : null }, c);
    c.toBlob(function (b) {
      if (!b) { setStatus('No se pudo exportar (imagen demasiado grande para este navegador).'); return; }
      offerDownload(b, base(media.name) + '_editada.' + (jpeg ? 'jpg' : 'png'), 'Descargar ' + (jpeg ? 'JPG' : 'PNG'));
      setStatus('Listo: ' + c.width + '×' + c.height + ' px.');
    }, jpeg ? 'image/jpeg' : 'image/png', +$('imgQ').value / 100);
  }

  function pickMime() {
    var list = ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4'];
    for (var i = 0; i < list.length; i++) if (window.MediaRecorder && MediaRecorder.isTypeSupported(list[i])) return list[i];
    return '';
  }

  async function exportVideo() {
    if (!window.MediaRecorder || !HTMLCanvasElement.prototype.captureStream) {
      setStatus('Este navegador no puede grabar video. Usa Chrome, Edge o Firefox.'); return;
    }
    var v = media.el, start = S.trim.start, end = S.trim.end || v.duration;
    resetOutputs(); stopPlayback(); setBusy(true); cancelled = false;
    var rs = Studio.rotatedSize(media.w, media.h, S.rot);
    var maxSide = +$('vidMax').value, side = Math.max(rs.w * S.crop.w, rs.h * S.crop.h);
    var scale = maxSide ? Math.min(1, maxSide / side) : 1;
    var out = document.createElement('canvas');
    var opts = { scale: scale, fast: true };
    Studio.render(v, media.w, media.h, S, opts, out);
    var stream = out.captureStream(30), hasAudio = false;
    try {
      if (!media.audio) {
        var ac = new (window.AudioContext || window.webkitAudioContext)();
        var node = ac.createMediaElementSource(v), dest = ac.createMediaStreamDestination();
        node.connect(dest); node.connect(ac.destination);
        media.audio = { ac: ac, node: node, dest: dest };
      }
      await media.audio.ac.resume();
      media.audio.node.disconnect(media.audio.ac.destination); // no suena durante la exportación
      v.muted = false; v.volume = 1;
      media.audio.dest.stream.getAudioTracks().forEach(function (t) { stream.addTrack(t); hasAudio = true; });
    } catch (e) { hasAudio = false; }

    var mime = pickMime();
    var rec = new MediaRecorder(stream, mime ? { mimeType: mime, videoBitsPerSecond: 8000000 } : undefined);
    var chunks = [];
    rec.ondataavailable = function (e) { if (e.data && e.data.size) chunks.push(e.data); };
    var stopped = new Promise(function (res) { rec.onstop = res; });
    var finish, done = new Promise(function (res) { finish = res; });
    var bar = $('bar'); bar.hidden = false; bar.value = 0;
    $('cancelExport').onclick = function () { cancelled = true; finish(); };
    setStatus('Exportando… (' + (hasAudio ? 'con audio' : 'sin audio') + '). Mantén esta pestaña abierta.');

    v.currentTime = start;
    await new Promise(function (res) { var h = function () { v.removeEventListener('seeked', h); res(); }; v.addEventListener('seeked', h); setTimeout(res, 400); });
    function tick() {
      if (cancelled) return;
      Studio.render(v, media.w, media.h, S, opts, out);
      bar.value = Math.min(1, (v.currentTime - start) / Math.max(0.1, end - start));
      if (v.currentTime >= end - 0.02 || v.ended) { finish(); return; }
      schedule(tick);
    }
    v.addEventListener('ended', finish, { once: true });
    rec.start(1000);
    try { await v.play(); } catch (e) {
      rec.stop(); await stopped; setBusy(false); setStatus('El navegador bloqueó la reproducción. Toca Exportar otra vez.'); return;
    }
    tick();
    await done;
    v.pause(); if (!cancelled) Studio.render(v, media.w, media.h, S, opts, out);
    rec.stop(); await stopped;
    try { media.audio.node.connect(media.audio.ac.destination); } catch (e) {}
    v.currentTime = start; setBusy(false); bar.hidden = true;
    if (cancelled) { setStatus('Exportación cancelada.'); return; }
    var type = (mime || 'video/webm').split(';')[0];
    var blob = new Blob(chunks, { type: type });
    var url = offerDownload(blob, base(media.name) + '_editado.' + (type === 'video/mp4' ? 'mp4' : 'webm'), 'Descargar video');
    var rv = $('result'); rv.src = url; rv.hidden = false;
    setStatus('Listo.');
    requestDraw();
  }
})();
