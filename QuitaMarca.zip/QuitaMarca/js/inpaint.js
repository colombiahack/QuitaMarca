/* QuitaMarca: relleno de regiones rectangulares (inpainting armónico).
 * Interpola los bordes conocidos y suaviza con iteraciones Gauss-Seidel
 * (ecuación de Laplace). Funciona en navegador y en Node (para pruebas). */
(function (root) {
  'use strict';

  /**
   * @param {Uint8ClampedArray} data  píxeles RGBA de W*H
   * @param {number} W
   * @param {number} H
   * @param {{x:number,y:number,w:number,h:number}} rect  zona a rellenar (px)
   * @param {{margin?:number,iterations?:number}} [opts]
   */
  function fillRect(data, W, H, rect, opts) {
    opts = opts || {};
    var m = opts.margin == null ? 2 : opts.margin;
    var iters = opts.iterations == null ? 60 : opts.iterations;
    var x0 = Math.max(0, Math.floor(rect.x - m));
    var y0 = Math.max(0, Math.floor(rect.y - m));
    var x1 = Math.min(W - 1, Math.ceil(rect.x + rect.w + m) - 1);
    var y1 = Math.min(H - 1, Math.ceil(rect.y + rect.h + m) - 1);
    var w = x1 - x0 + 1, h = y1 - y0 + 1;
    if (w <= 0 || h <= 0) return;
    var hasL = x0 > 0, hasR = x1 < W - 1, hasT = y0 > 0, hasB = y1 < H - 1;
    if (!(hasL || hasR || hasT || hasB)) return; // no hay píxeles conocidos

    function px(x, y, c) { return data[(y * W + x) * 4 + c]; }
    var buf = new Float32Array(w * h * 3);

    // Inicialización: interpolación lineal entre los bordes conocidos
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        for (var c = 0; c < 3; c++) {
          var sum = 0, n = 0, v;
          if (hasL || hasR) {
            if (hasL && hasR) {
              var s = (x + 1) / (w + 1);
              v = px(x0 - 1, y0 + y, c) * (1 - s) + px(x1 + 1, y0 + y, c) * s;
            } else v = hasL ? px(x0 - 1, y0 + y, c) : px(x1 + 1, y0 + y, c);
            sum += v; n++;
          }
          if (hasT || hasB) {
            if (hasT && hasB) {
              var t = (y + 1) / (h + 1);
              v = px(x0 + x, y0 - 1, c) * (1 - t) + px(x0 + x, y1 + 1, c) * t;
            } else v = hasT ? px(x0 + x, y0 - 1, c) : px(x0 + x, y1 + 1, c);
            sum += v; n++;
          }
          buf[(y * w + x) * 3 + c] = sum / n;
        }
      }
    }

    // Suavizado: cada píxel = promedio de sus 4 vecinos (Gauss-Seidel)
    for (var it = 0; it < iters; it++) {
      for (y = 0; y < h; y++) {
        for (x = 0; x < w; x++) {
          for (c = 0; c < 3; c++) {
            var i = (y * w + x) * 3 + c, acc = 0, cnt = 0;
            if (x > 0) { acc += buf[i - 3]; cnt++; } else if (hasL) { acc += px(x0 - 1, y0 + y, c); cnt++; }
            if (x < w - 1) { acc += buf[i + 3]; cnt++; } else if (hasR) { acc += px(x1 + 1, y0 + y, c); cnt++; }
            if (y > 0) { acc += buf[i - w * 3]; cnt++; } else if (hasT) { acc += px(x0 + x, y0 - 1, c); cnt++; }
            if (y < h - 1) { acc += buf[i + w * 3]; cnt++; } else if (hasB) { acc += px(x0 + x, y1 + 1, c); cnt++; }
            if (cnt) buf[i] = acc / cnt;
          }
        }
      }
    }

    for (y = 0; y < h; y++) {
      for (x = 0; x < w; x++) {
        var o = ((y0 + y) * W + (x0 + x)) * 4, b = (y * w + x) * 3;
        data[o] = buf[b]; data[o + 1] = buf[b + 1]; data[o + 2] = buf[b + 2];
      }
    }
  }

  var api = { fillRect: fillRect };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.QuitaMarca = api;
})(typeof self !== 'undefined' ? self : this);
