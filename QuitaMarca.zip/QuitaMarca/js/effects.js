/* Efectos de píxeles: desenfoque, pixelado y ajustes de color.
 * Funciona en navegador y en Node (para pruebas). Datos RGBA (Uint8ClampedArray). */
(function (root) {
  'use strict';

  function clamp(v) { return v < 0 ? 0 : v > 255 ? 255 : v; }

  function boxH(src, dst, w, h, r) {
    var win = 2 * r + 1;
    for (var y = 0; y < h; y++) {
      for (var c = 0; c < 3; c++) {
        var base = y * w * 3 + c, sum = 0, k;
        for (k = -r; k <= r; k++) sum += src[base + (k < 0 ? 0 : k >= w ? w - 1 : k) * 3];
        for (var x = 0; x < w; x++) {
          dst[base + x * 3] = sum / win;
          var add = x + r + 1, rem = x - r;
          sum += src[base + (add >= w ? w - 1 : add) * 3] - src[base + (rem < 0 ? 0 : rem) * 3];
        }
      }
    }
  }

  function boxV(src, dst, w, h, r) {
    var win = 2 * r + 1, s = w * 3;
    for (var x = 0; x < w; x++) {
      for (var c = 0; c < 3; c++) {
        var base = x * 3 + c, sum = 0, k;
        for (k = -r; k <= r; k++) sum += src[base + (k < 0 ? 0 : k >= h ? h - 1 : k) * s];
        for (var y = 0; y < h; y++) {
          dst[base + y * s] = sum / win;
          var add = y + r + 1, rem = y - r;
          sum += src[base + (add >= h ? h - 1 : add) * s] - src[base + (rem < 0 ? 0 : rem) * s];
        }
      }
    }
  }

  function bounds(data, W, H, rect) {
    var x0 = Math.max(0, Math.round(rect.x)), y0 = Math.max(0, Math.round(rect.y));
    var x1 = Math.min(W, Math.round(rect.x + rect.w)), y1 = Math.min(H, Math.round(rect.y + rect.h));
    return { x0: x0, y0: y0, w: x1 - x0, h: y1 - y0 };
  }

  /** Desenfoque de caja (3 pasadas ≈ gaussiano) dentro de rect. */
  function blurRect(data, W, H, rect, radius) {
    var b = bounds(data, W, H, rect);
    if (b.w < 1 || b.h < 1) return;
    var r = Math.max(1, Math.round(radius));
    var a = new Float32Array(b.w * b.h * 3), t = new Float32Array(b.w * b.h * 3), x, y, c;
    for (y = 0; y < b.h; y++) for (x = 0; x < b.w; x++) for (c = 0; c < 3; c++)
      a[(y * b.w + x) * 3 + c] = data[((b.y0 + y) * W + b.x0 + x) * 4 + c];
    for (var p = 0; p < 3; p++) { boxH(a, t, b.w, b.h, r); boxV(t, a, b.w, b.h, r); }
    for (y = 0; y < b.h; y++) for (x = 0; x < b.w; x++) for (c = 0; c < 3; c++)
      data[((b.y0 + y) * W + b.x0 + x) * 4 + c] = a[(y * b.w + x) * 3 + c];
  }

  /** Pixelado en bloques de `block` px dentro de rect. */
  function pixelateRect(data, W, H, rect, block) {
    var b = bounds(data, W, H, rect);
    if (b.w < 1 || b.h < 1) return;
    block = Math.max(2, Math.round(block));
    for (var by = 0; by < b.h; by += block) {
      for (var bx = 0; bx < b.w; bx += block) {
        var bw = Math.min(block, b.w - bx), bh = Math.min(block, b.h - by);
        var sr = 0, sg = 0, sb = 0, n = bw * bh, x, y, i;
        for (y = 0; y < bh; y++) for (x = 0; x < bw; x++) {
          i = ((b.y0 + by + y) * W + b.x0 + bx + x) * 4;
          sr += data[i]; sg += data[i + 1]; sb += data[i + 2];
        }
        sr /= n; sg /= n; sb /= n;
        for (y = 0; y < bh; y++) for (x = 0; x < bw; x++) {
          i = ((b.y0 + by + y) * W + b.x0 + bx + x) * 4;
          data[i] = sr; data[i + 1] = sg; data[i + 2] = sb;
        }
      }
    }
  }

  function isNeutral(o) {
    return !o || (!o.brightness && !o.contrast && !o.saturation && !o.gray);
  }

  /** Brillo/contraste/saturación (-100..100) y blanco y negro. */
  function adjust(data, o) {
    if (isNeutral(o)) return;
    var cc = (o.contrast || 0) * 2.55;
    var factor = (259 * (cc + 255)) / (255 * (259 - cc));
    var bright = (o.brightness || 0) * 2.55;
    var lut = new Uint8ClampedArray(256), i;
    for (i = 0; i < 256; i++) lut[i] = clamp(factor * (i - 128) + 128 + bright);
    var sat = o.gray ? 0 : 1 + (o.saturation || 0) / 100;
    for (i = 0; i < data.length; i += 4) {
      var r = lut[data[i]], g = lut[data[i + 1]], b = lut[data[i + 2]];
      if (sat !== 1) {
        var l = 0.299 * r + 0.587 * g + 0.114 * b;
        r = clamp(l + (r - l) * sat); g = clamp(l + (g - l) * sat); b = clamp(l + (b - l) * sat);
      }
      data[i] = r; data[i + 1] = g; data[i + 2] = b;
    }
  }

  var api = { blurRect: blurRect, pixelateRect: pixelateRect, adjust: adjust, isNeutral: isNeutral };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Effects = api;
})(typeof self !== 'undefined' ? self : this);
