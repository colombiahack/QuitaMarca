/* Render del editor: geometría (girar/voltear/recortar) -> zonas (quitar marca,
 * desenfocar, pixelar) -> ajustes de color -> texto y logo.
 * Se usa igual para la vista previa y para exportar. */
(function (root) {
  'use strict';

  /** Tamaño del cuadro girado y sin recortar, sin escalar. */
  function rotatedSize(w, h, rot) { return (rot % 2) ? { w: h, h: w } : { w: w, h: h }; }

  function applyZone(ctx, OW, OH, z, opts) {
    var r = { x: Math.round(z.x * OW), y: Math.round(z.y * OH), w: Math.max(1, Math.round(z.w * OW)), h: Math.max(1, Math.round(z.h * OH)) };
    var ref = Math.max(OW, OH) / 1000;
    var margin = Math.max(1, Math.round((z.margin == null ? 3 : z.margin) * Math.max(OW, OH) / 960));
    var pad = z.kind === 'fill' ? margin + 2 : 0;
    var ax = Math.max(0, r.x - pad), ay = Math.max(0, r.y - pad);
    var bx = Math.min(OW, r.x + r.w + pad), by = Math.min(OH, r.y + r.h + pad);
    var aw = bx - ax, ah = by - ay;
    if (aw < 1 || ah < 1) return;
    var id = ctx.getImageData(ax, ay, aw, ah);
    var local = { x: r.x - ax, y: r.y - ay, w: r.w, h: r.h };
    if (z.kind === 'fill') root.QuitaMarca.fillRect(id.data, aw, ah, local, { margin: margin, iterations: opts.fast ? 25 : 60 });
    else if (z.kind === 'blur') root.Effects.blurRect(id.data, aw, ah, local, Math.max(1, z.strength * ref));
    else root.Effects.pixelateRect(id.data, aw, ah, local, Math.max(2, z.strength * ref * 2.5));
    ctx.putImageData(id, ax, ay);
  }

  function drawText(ctx, OW, OH, t) {
    if (!t || !t.value) return;
    var px = Math.max(6, (t.size / 100) * OH);
    ctx.save();
    ctx.font = (t.bold ? 'bold ' : '') + px + 'px system-ui, -apple-system, "Segoe UI", sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.lineJoin = 'round';
    var lines = String(t.value).split('\n'), lh = px * 1.2;
    var y0 = t.y * OH - ((lines.length - 1) * lh) / 2;
    lines.forEach(function (line, i) {
      var x = t.x * OW, y = y0 + i * lh;
      if (t.outline) {
        ctx.lineWidth = Math.max(2, px / 7); ctx.strokeStyle = lum(t.color) > 140 ? '#000' : '#fff';
        ctx.strokeText(line, x, y);
      }
      ctx.fillStyle = t.color; ctx.fillText(line, x, y);
    });
    ctx.restore();
  }
  function lum(hex) {
    var m = /^#?([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/i.exec(hex || '');
    if (!m) return 255;
    return 0.299 * parseInt(m[1], 16) + 0.587 * parseInt(m[2], 16) + 0.114 * parseInt(m[3], 16);
  }

  function drawLogo(ctx, OW, OH, l) {
    if (!l || !l.img) return;
    var w = (l.size / 100) * OW, h = w * (l.img.naturalHeight / l.img.naturalWidth);
    ctx.save(); ctx.globalAlpha = l.opacity / 100;
    ctx.drawImage(l.img, l.x * OW - w / 2, l.y * OH - h / 2, w, h);
    ctx.restore();
  }

  /**
   * @param source  HTMLImageElement | HTMLVideoElement
   * @param sw,sh   tamaño original del medio
   * @param S       estado: {rot,flip,crop,zones,adjust,text,logo}
   * @param opts    {scale, ignoreCrop, fast, background}
   * @param canvas  canvas destino (se redimensiona si hace falta)
   */
  function render(source, sw, sh, S, opts, canvas) {
    opts = opts || {};
    var scale = opts.scale || 1;
    var rs = rotatedSize(sw, sh, S.rot);
    var c = opts.ignoreCrop ? { x: 0, y: 0, w: 1, h: 1 } : S.crop;
    var OW = Math.max(2, Math.round(rs.w * c.w * scale));
    var OH = Math.max(2, Math.round(rs.h * c.h * scale));
    if (canvas.width !== OW || canvas.height !== OH) { canvas.width = OW; canvas.height = OH; }
    var ctx = canvas.getContext('2d', { willReadFrequently: true });

    // 1) Geometría
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    if (opts.background) { ctx.fillStyle = opts.background; ctx.fillRect(0, 0, OW, OH); } else ctx.clearRect(0, 0, OW, OH);
    ctx.save();
    ctx.scale(OW / (rs.w * c.w), OH / (rs.h * c.h));
    ctx.translate(-c.x * rs.w, -c.y * rs.h);
    if (S.flip) { ctx.translate(rs.w, 0); ctx.scale(-1, 1); }
    if (S.rot === 1) { ctx.translate(sh, 0); ctx.rotate(Math.PI / 2); }
    else if (S.rot === 2) { ctx.translate(sw, sh); ctx.rotate(Math.PI); }
    else if (S.rot === 3) { ctx.translate(0, sw); ctx.rotate(-Math.PI / 2); }
    ctx.drawImage(source, 0, 0, sw, sh);
    ctx.restore();

    // 2) Zonas
    for (var i = 0; i < S.zones.length; i++) applyZone(ctx, OW, OH, S.zones[i], opts);

    // 3) Ajustes de color
    if (!root.Effects.isNeutral(S.adjust)) {
      var id = ctx.getImageData(0, 0, OW, OH);
      root.Effects.adjust(id.data, S.adjust);
      ctx.putImageData(id, 0, 0);
    }

    // 4) Texto y logo
    drawLogo(ctx, OW, OH, S.logo);
    drawText(ctx, OW, OH, S.text);
    return { w: OW, h: OH };
  }

  root.Studio = { render: render, rotatedSize: rotatedSize };
})(typeof self !== 'undefined' ? self : this);
